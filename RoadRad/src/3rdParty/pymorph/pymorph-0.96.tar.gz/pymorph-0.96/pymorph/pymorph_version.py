__version__ = '0.96'
__version_info__ = (0, 96)
