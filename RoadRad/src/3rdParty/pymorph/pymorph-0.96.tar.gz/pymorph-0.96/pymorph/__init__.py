import mmorph
import text
from mmorph import *
from text import *
from pymorph_version import __version__

__doc__ = mmorph.__doc__
__all__ = mmorph.__all__ + ['text']
